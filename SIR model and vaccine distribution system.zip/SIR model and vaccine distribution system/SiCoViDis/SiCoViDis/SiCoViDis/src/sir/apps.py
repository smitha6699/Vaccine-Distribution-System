from django.apps import AppConfig


class SirConfig(AppConfig):
    name = 'sir'
