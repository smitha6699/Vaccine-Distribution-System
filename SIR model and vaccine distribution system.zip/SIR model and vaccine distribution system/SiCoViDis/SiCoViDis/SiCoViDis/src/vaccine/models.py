from django.db import models


class PredResults(models.Model):

    sepal_length = models.FloatField()